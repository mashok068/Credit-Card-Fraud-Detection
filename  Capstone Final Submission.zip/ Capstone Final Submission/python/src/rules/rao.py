""" 
-------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------
Credit Card Fraud Detection Capstone Project using Apache PySpark & Kafka Streaming using Spark 2.3.0 on Hadoop 2.6

Project : By Malathi Ashok
Date    : 09/08/2021

Class defined to encapsulate the Rule Validation Logic using the check method
-------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------
"""
import sys
sys.path.append('../')
from db.geo_map import GEO_Map
from datetime import datetime
import pandas as pd

class Check_Rules():
	__instance = None

	@staticmethod
	def get_instance():
		""" Static access method. """
		if Check_Rules.__instance == None:
			Check_Rules()
		return Check_Rules.__instance

	def __init__(self):
		""" Virtually private constructor. """
		if Check_Rules.__instance != None:
			raise Exception("This class is a singleton!")
		else:
			Check_Rules.__instance = self

        def check(self, amount, ucl, member_score, post_code, last_post_code, current_transaction_dt, last_transaction_date):
                geomap = GEO_Map.get_instance()

                ucl = float(ucl)
                member_score = int(member_score)

                #Get Current Lattitude & Longitude
		current_lattitude = geomap.get_lat(post_code).values
   		current_longitude = geomap.get_long(post_code).values

                #Get Previous Lattitude & Longitude
   		prev_lattitude = geomap.get_lat(last_post_code).values
   		prev_longitude = geomap.get_long(last_post_code).values

                #Get Distance between the two places(Current transaction & Previous Transaction Coordinates)
   		distance = geomap.distance(current_lattitude, current_longitude, prev_lattitude, prev_longitude)
                print("Distance : ", distance)  

   		date_format_str = '%d-%m-%Y %H:%M:%S'  
   		start = datetime.strptime(last_transaction_date, date_format_str)
   		end = datetime.strptime(current_transaction_dt, date_format_str)

   		# Get time interval between two timstamps
   		time_difference = (end - start).total_seconds()

                #Check for 3 Validation rules for classifying a transaction as FRAUD or GENUINE

   		#If transaction amount is greater than UCL from the lookup table, classify as "FRAUD"
   		if  (amount > ucl): 
      	 	   return "FRAUD"

      	 	# if member_score from lookup table is less then 200, then classify the transaction as "FRAUD" 
   		if (member_score < 200 ):
      	 	   return "FRAUD"

      	 	#If time difference between two card transactions is too less, classify the transaction as "FRAUD"
   		if ( time_difference < 4*distance):
      	 	   return "FRAUD"

                #If all three validation rules passed, classify the transaction as GENUINE
   		return "GENUINE"
