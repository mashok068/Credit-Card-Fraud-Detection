""" 
-------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------
Credit Card Fraud Detection Capstone Project using Apache PySpark & Kafka Streaming using Spark 2.3.0 on Hadoop 2.6

Project : By Malathi Ashok
Date    : 09/08/2021
-------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------
"""

# System dependencies for CDH
import os
import sys, path
import json

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *

from db.dao import HBaseDao
from rules.rao import Check_Rules
import uuid


####################################################################################
# UDF function for finding the status of each transaction - as Genuine or Fraud
####################################################################################
def get_status(card_id, member_id, amount, postcode, pos_id, transaction_dt):

   hbase_conn = HBaseDao.get_instance()
   ck_rules = Check_Rules.get_instance()

   #Get Card Information from the card_lookup table using the card_id as the row-key
   card_info = hbase_conn.get_data(card_id, "card_lookup")

   if (card_info is not None):
	ucl = card_info['cf:ucl']
   	last_postcode  =  card_info['cf:postcode']
   	last_transaction_dt = card_info['cf:transaction_dt']
   	member_score = card_info['cf:score']

        # Call the check function of Check_Rules to validate card transaction as "FRAUD" or "GENUINE"
   	status = ck_rules.check(amount, ucl, member_score, postcode, last_postcode, transaction_dt, last_transaction_dt)

        # IF Transaction is Genuine, update the card_lookup table in hbase
        if (status == "GENUINE"):
           card_info['cf:postcode'] = postcode
           card_info['cf:transaction_dt'] = transaction_dt
           hbase_conn.write_data(card_id, card_info, "card_lookup")

        # Update the Card_Transaction Table in hbase for both "FRAUD" and "GENUINE"
        transaction_data = {
              b'cardDetail:card_id': card_id
              ,b'cardDetail:member_id': member_id 
              ,b'transactionDetail:amount': str(amount)
              ,b'transactionDetail:postcode': postcode
              ,b'transactionDetail:pos_id': pos_id
              ,b'transactionDetail:transaction_dt': transaction_dt
              ,b'transactionDetail:status': status
        }
        row_key =  uuid.uuid4().hex
        hbase_conn.write_data(row_key, transaction_data, "card_transactions_hbase") 

   	return status

if __name__ == "__main__": 

   host = "18.211.252.152"
   port = "9092"
   topic = "transactions-topic-verified"


   # Read Input from kafka
   spark = SparkSession \
       .builder \
       .appName("CreditCardFraudDetection") \
       .getOrCreate()
   spark.sparkContext.setLogLevel("ERROR")

   # Read Input from the kafka server as a Json String
   card_transactionInfo = spark.readStream \
       .format("kafka") \
       .option("kafka.bootstrap.servers", host + ":" + port) \
       .option("startingOffsets", "earliest") \
       .option("subscribe", topic).load()

   # Define schema of a single order
   jsonSchema = StructType() \
       .add("card_id", StringType()) \
       .add("member_id", StringType()) \
       .add("amount", DoubleType()) \
       .add("postcode", StringType()) \
       .add("pos_id", StringType()) \
       .add("transaction_dt", StringType()) 

   # Extract individual Columns from the Json into transactionStream DataStream
   card_transactionStream = card_transactionInfo.select(from_json(col("value").cast("string"), jsonSchema).alias("data")).select("data.*")
   
   ##################################################################################################
   # Define the UDFs with the utility functions
   ##################################################################################################
   add_status = udf(get_status, StringType())

   #################################################################################################
   # Validate the Card Transaction Data as Genuine or Fraud and add the additional column
   #################################################################################################
   newStream = card_transactionStream \
       .withColumn("status", add_status(card_transactionStream.card_id, card_transactionStream.member_id, card_transactionStream.amount, card_transactionStream.postcode, card_transactionStream.pos_id, card_transactionStream.transaction_dt))

   # Write the Transaction Data Stream to Console
   query = newStream \
       .select("*") \
       .writeStream \
       .outputMode("append") \
       .format("console") \
       .option("truncate", "false") \
       .trigger(processingTime="1 minute") \
       .start()

   # Run the process until a termination request comes in
   query.awaitTermination()

